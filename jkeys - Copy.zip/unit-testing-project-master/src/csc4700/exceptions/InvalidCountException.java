package csc4700.exceptions;

public class InvalidCountException extends RuntimeException {
}
